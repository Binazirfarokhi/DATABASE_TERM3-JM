------------------------------------------------------------
-- TASK 4.2                                                -
------------------------------------------------------------

INSERT INTO movies("name", director, "year", genre) VALUES
('Harry Potter and the Sorcerer''s Stone', 'Chris Columbus', 2001, 'Fantasy'),
('Pride & Prejudice', 'Joe Wright', 2005, 'Drama'),
('Home Alone', 'Chris Columbus', 1990, 'Comedy');
------------------------------------------------------------