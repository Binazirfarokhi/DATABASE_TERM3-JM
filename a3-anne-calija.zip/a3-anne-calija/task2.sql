------------------------------------------------------------
-- TASK 2                                                  -
------------------------------------------------------------
-- 2.a

    SELECT title, author, "year"
    FROM longlist
    WHERE "year" = 2022;

-- 2.b

    SELECT title, author, "year"
    FROM longlist
    WHERE author = 'Willem Anker';

-- 2.c

    SELECT title, author, "year"
    FROM longlist
    WHERE "year" IS NOT 2022;

-- 2.d
-- -- 2.d.i - OR

        SELECT title, author, "year"
        FROM longlist
        WHERE "year" = 2018 OR "year" = 2019;

-- -- 2.d.ii - AND

        SELECT title, author, "year"
        FROM longlist
        WHERE "year" >= 2018 AND "year" <= 2019;

-- -- 2.d.iii - BETWEEN

        SELECT title, author, "year"
        FROM longlist
        WHERE "year" BETWEEN 2018 AND 2019;

-- -- 2.d.iv

        SELECT title, author, "year"
        FROM longlist
        WHERE "year" IN (2018, 2019);

-- 2.e

    SELECT title, author, "year"
    FROM longlist
    WHERE "year" IN (2018, 2019)
    AND format = 'hardcover';

------------------------------------------------------------