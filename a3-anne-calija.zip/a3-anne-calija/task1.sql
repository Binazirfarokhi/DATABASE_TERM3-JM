------------------------------------------------------------
-- TASK 1                                                  -
------------------------------------------------------------
-- 1.a

    SELECT author, title, isbn
    FROM longlist;

-- 1.b

    SELECT author, title, isbn 
    FROM longlist
    LIMIT 4;

-- 1.c

    SELECT author, title, isbn
    FROM longlist
    ORDER BY isbn ASC;

-- 1.d

    SELECT author, title, isbn
    FROM longlist
    ORDER BY isbn ASC
    LIMIT 4;

-- 1.e

    SELECT author, title, isbn
    FROM longlist
    ORDER BY isbn ASC
    LIMIT 4 OFFSET 2;
------------------------------------------------------------