------------------------------------------------------------
-- TASK 3                                                  -
------------------------------------------------------------
-- 3.a

SELECT title, publisher
FROM longlist
WHERE publisher LIKE '%Press%';

-- 3.b

SELECT title, publisher
FROM longlist
WHERE title LIKE '%Live%'
OR title LIKE '%Love%';

-- 3.c

SELECT title, publisher
FROM longlist
WHERE title LIKE '%L_ve%'

------------------------------------------------------------