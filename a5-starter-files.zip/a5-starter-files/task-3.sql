SELECT '3' AS 'Task';

INSERT INTO admin_divisions (type) VALUES 
(
    'province'
);

INSERT INTO admin_divisions (name, type) VALUES 
(
    '',
    'province'
);

INSERT INTO admin_divisions (name, type) VALUES 
(
    'California',
    'state'
);

INSERT INTO settlements (name, admin_division, type, mean_temp) VALUES 
(
    'North Pole',
    'Northwest Territories',
    'village',
    -60
);

INSERT INTO settlements (name, admin_division, type, mean_temp) VALUES 
(
    'Toronto',
    'Ontario',
    'metropolis',
    9.0
);

INSERT INTO settlements (name, admin_division, type, mean_temp) VALUES 
(
    'Los Angeles',
    'California',
    'city',
    18.8
);

INSERT INTO settlements (name, admin_division, type, mean_temp) VALUES 
(
    'Stratford',
    'Ontario',
    'village',
    1.9
);


