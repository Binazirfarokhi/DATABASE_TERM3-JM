--join the sql 
--the table we are working is lognlist advance db 
-- join keyword will help to join two tables 
--purpose of join : create a set of result for each row has columns from more than one table - 
-- let's get all books 
--SELECT * FROM books;
--get the name of publisher 
--SELECT * FROM books
--JOIN publishers ON books.publisher_id; 
-- JOIN ON - publisher has foregin key 
-- * is getting all the columns 
--only the book title and the publisher name 
 
--SELECT books.title, publisher.publisher FROM books
--JOIN publishers ON books.publisher_id = publisher.id; 
-- having direction will help to join two tables - PK PA 
--getting books with the ID of the translator; 
--SELECT books.title, translated.translator_id FROM books
--JOIN trasnlated  ON books.id = translated.book_id;
-- some of the books in the db do not have translator . so those books are not showing up in the result set. 
-- by default, JOIN performs an inner join, which means only rowss that have a match in both tables are fetched, we can do a LEFT JOIN which will get all the book with only thr translort books can show the match. 
--SELECT books.title, translated.translator_id FROM books
--LEFT JOIN trasnlated  ON books.id = translated.book_id;
-- get all transalrot RIGHT JOIN : seconf table ins considered as a RIGHT and first talbe is considered as first table 
SELECT books.title, translated.translator_id, translator.name AS "translator name" FROM books
LEFT JOIN translated  ON books.id = translated.book_id
LEFT JOIN translator ON translated.translator_id = translator_id; 