-- creating two table for storing pets nad other ofr storing pet types one to many relationship. 
-- pet ca nhave one type, but the tyoe can beloing to mant pets 
-- it will be ocnnected by foreign  key 
-- to avoid errors with trying to create tow tables that already exist, we can use drop table if exist: 
-- ENforce foreign key 
PRAGMA foreign_keys = ON: 
DROP TABLE IF EXISTS pets;
DROP TABLE IF EXISTS types; 
CREATE TABLE pets (
id      INTEGER,
name    TEXT,
age     INTEGER CHECK (age > 0 ) 
,
type    INTEGER, 
PRIMARY KEY (id),
FOREIGN KEY (type) REFERENCES  types(id) 
);
--challenge : make the type talbe it should have name like dog bird and etc a class like mamal amphibian and an id set up pk and FK 
CREATE TABLE types (

id   INTEGER ,
name  TEXT,
class TEXT,
difficulty REAL, -- can have a decimal 
PRIMARY KEY (id),

);
-- challenge add atype of pet and a pet should have an exisiting type 
-- if the pk is an integer 
INSERT INTO types ( name ,class, difficulty) VALUES
(
'dog',
'mamal',
4.5
),
(
'cat',
'mamal',
5

);
INSERT INTO pets ( name, age, type) VALUES (
'scurffy',
5 , 
1

),

(
'spoots'
2,
--if you do not know th id of that animal 
(SELECT id FROM types WHERE name='cat')
)
-- challenge : add two more types 
