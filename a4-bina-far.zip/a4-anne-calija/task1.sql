-- Task 1 - Book Ratings

-- A
SELECT '1 a' AS "Task";

SELECT ROUND(AVG(rating), 1) AS average_rating from ratings
GROUP BY book_id
ORDER BY average_rating DESC;

-- B
SELECT '1 b' AS "Task";

SELECT book_id, ROUND(AVG(rating), 1) AS average_rating from ratings
GROUP BY book_id
HAVING average_rating >= 4
ORDER BY average_rating DESC;


-- C
SELECT '1 c' AS "Task";

SELECT title FROM books
WHERE id IN (SELECT best_books.book_id FROM
(SELECT book_id, ROUND(AVG(rating), 1) AS average_rating from ratings
GROUP BY book_id
HAVING average_rating >= 4
ORDER BY average_rating DESC) AS best_books);