-- Task 2: Finding Books By Author
-- A
SELECT '2 a' AS "Task";

SELECT title AS "Books by Author ID 12", id AS "Book ID" FROM books
WHERE id IN (SELECT book_id from authored where author_id = 12);


-- B

SELECT '2 b' AS "Task";

SELECT title AS "Books by Jon Fosse" FROM books
WHERE id IN 
(SELECT book_id FROM authored WHERE author_id = 
(SELECT id FROM authors WHERE "name" = 'Jon Fosse'));

-- C
SELECT '2 c' AS "Task";

-- TO CONFIRM IF VALID
-- Write a query (with a subquery) to get the ID of the author with the largest number of books in the database
SELECT COUNT(author_id) AS "Most Books", author_id from authored
GROUP BY author_id
ORDER BY "Most Books" DESC
LIMIT 1;


-- D
SELECT '2 d' AS "Task";

CREATE TEMP TABLE IF NOT EXISTS "Most Books" AS 
SELECT COUNT(author_id) AS "Most Books", author_id from authored
GROUP BY author_id
ORDER BY "Most Books" DESC
LIMIT 1;

SELECT "name" as "Author with Most Books" from authors
WHERE id = (SELECT author_id FROM temp."Most Books");



