-- Task 4 - More on Grouping

-- A
SELECT '4 a' AS "Task";

SELECT COUNT(*) AS number_of_books,
CASE
    WHEN pages < 200 THEN 'short'
    WHEN pages < 500 THEN 'medium'
    ELSE 'long'
    END book_length
FROM books
GROUP BY book_length;