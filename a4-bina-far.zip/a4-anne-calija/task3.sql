-- Task 3 - Sets

-- A
SELECT '3 a' AS "Task";

SELECT "name" AS "Author and Translator" FROM authors
INTERSECT
SELECT "name" FROM translators;


-- B
SELECT '3 b' AS "Task";

SELECT "Author and Translator" FROM
(SELECT "name" AS "Author and Translator", 'Author' AS "Role" FROM authors
UNION
SELECT "name", 'Translator' AS "Role" FROM translators)
GROUP BY "Author and Translator"
HAVING COUNT(*) = 1;