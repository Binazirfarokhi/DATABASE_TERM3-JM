import { connection, database } from './database.js'; 

let queries = async () => {
    try {
        await connection;

        // Your queries here
    }
    catch(error) {
        console.log(error)
    }
    finally {
        // stop the program at end 
        process.exit();
    }
}

queries();
