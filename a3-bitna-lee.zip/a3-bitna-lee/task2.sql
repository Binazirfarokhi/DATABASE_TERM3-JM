-- SQLite
-- Task 2: WHERE filter conditions
-- a) Get the title, author, and year for all books from 2022.
SELECT title, author, year FROM longlist where year = 2022;

-- b) Get the title, author, and year for all books written by Willem Anker.
SELECT title, author, year FROM longlist where author = "Willem Anker";

-- c)Use the NOT keyword to get the title, author, and year of all books that were NOT written in 2020.
SELECT title, author, year FROM longlist where year NOT IN(2020);

-- d) Get the title, author, and year of all books written in 2018 and 2019. Figure out four ways to do this using each of the following keywords: 
-- i. OR 
SELECT title, author, year FROM longlist where year = 2018 OR year = 2019;

-- ii. AND. 
SELECT title, author, year FROM longlist where year >= 2018 AND year <= 2019;

-- iii. BETWEEN 
SELECT title, author, year FROM longlist where year BETWEEN 2018 and 2019;

-- iv. IN
SELECT title, author, year FROM longlist where year IN(2018, 2019);


-- e) Repeat any one of the four above queries, but also limit the results to books in hardcover format.
SELECT title, author, year FROM longlist where year IN(2018, 2019) AND format = "hardcover";