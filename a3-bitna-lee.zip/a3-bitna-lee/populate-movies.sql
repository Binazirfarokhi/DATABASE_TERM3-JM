-- SQLite
-- Task 4: Creating Databases and Tables
-- Create a new file called populate-movies.sql that adds three movies to the above table, with data for each column. (You can choose your favorite movies!)

INSERT INTO movies(name, director, year, genre) 
    VALUES 
        ('Parasite', 'Bong Joon-ho', 2019, 'Korean Thriller/Comedy'),
        ('Extreme Job', 'Lee Byeong-heon', 2019, 'Korean Comedy'),
        ('Hidden Figures', 'Theodore Melfi', 2016, 'Biography');


