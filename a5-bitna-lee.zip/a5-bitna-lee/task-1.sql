-- Task 1

-- a
SELECT b.title, b.id AS "bookID", author_id AS "authorID"
    FROM books b 
        JOIN authored ON authored.book_id = b.id;

-- b
SELECT b.title, b.id AS "bookID", author_id AS "authorID", authors.name AS "author"
    FROM books b 
        JOIN authored ON authored.book_id = b.id
        JOIN authors ON authors.id = authored.author_id;
        
-- c
SELECT b.title, b.id AS "bookID", p.publisher AS "publisher", authors.name AS "author"
    FROM books b 
        JOIN authored ON authored.book_id = b.id
        JOIN authors ON authors.id = authored.author_id
        JOIN publishers p ON p.id = b.publisher_id;
        
-- d
SELECT b.title, b.id AS "bookID", p.publisher AS "publisher", authors.name AS "author"
    FROM books b 
        JOIN authored ON authored.book_id = b.id
        JOIN authors ON authors.id = authored.author_id
        JOIN publishers p ON p.id = b.publisher_id
    ORDER BY book_id ASC
    LIMIT 10 OFFSET 5;
