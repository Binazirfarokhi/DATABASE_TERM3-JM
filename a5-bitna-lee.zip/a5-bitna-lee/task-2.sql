-- Task 2

-- a
PRAGMA foreign_keys = ON;
DROP TABLE IF EXISTS settlements;
DROP TABLE IF EXISTS admin_divisions;


-- b
CREATE TABLE admin_divisions (
    name            TEXT PRIMARY KEY 
                        CONSTRAINT "Name must have at least one character" 
                            CHECK(LENGTH(name) >0) NOT NULL,
    type            TEXT 
                        CONSTRAINT "Type must be province or territory" 
                            CHECK(type IN("province", "territory"))
);

CREATE TABLE settlements (
    name            TEXT 
                        CONSTRAINT "Name must have at least one character" 
                            CHECK(LENGTH(name) >0) NOT NULL,
    admin_division  TEXT 
                        CONSTRAINT "Name must have at least one character" 
                            CHECK(LENGTH(name) >0) NOT NULL,
    type            TEXT
                        CONSTRAINT "Type must be village, town or city" 
                            CHECK(type IN("village", "town", "city")),
    mean_temp       REAL
                        CONSTRAINT "Temp must be between -50 and +50" 
                            CHECK(mean_temp BETWEEN -50 AND 50),
    PRIMARY KEY (name, admin_division),
    FOREIGN KEY (admin_division) REFERENCES admin_divisions(name)
);


INSERT INTO admin_divisions (name, type)
    VALUES 
    ("Ontario", "province"),
    ("Quebec", "province"),
    ("Yukon", "territory"),
    ("Prince Edward Island", "province"),
    ("Northwest Territories", "territory");

INSERT INTO settlements (name, admin_division, type, mean_temp)
    VALUES 
    ("Stratford", "Ontario", "city", 7.4),
    ("Stratford", "Quebec", "town", 6.5),
    ("Sherbrooke", "Quebec", "city", 10.2),
    ("Sherbrooke", "Prince Edward Island", "village", 4.5),
    ("Dawson City", "Yukon", "town", -3.8);
    
    
    