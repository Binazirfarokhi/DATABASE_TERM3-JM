-- Task 2: Cities and Towns
DROP TABLE IF EXISTS settlements;
DROP TABLE IF EXISTS admin_divisions;


-- A
SELECT '2 a - Ensure foreign key constraints are enforced. (PRAGMA foreign_keys = ON)' AS "Task";
PRAGMA foreign_keys = ON;


-- B
SELECT '2 b - Creating admin_divisions table with name (PK) and type' AS "Task";

CREATE TABLE admin_divisions (
    name
        TEXT NOT NULL
        CONSTRAINT "Name must have at least one character." CHECK (LENGTH(name) > 0),
    type
        TEXT
        CONSTRAINT "Type must be either 'province' or 'territory'" CHECK (type IN ('province', 'territory')),
    PRIMARY KEY(name)
);

-- C
SELECT '2 c - Creating settlements table with name & admin_division (PK - Composite), and admin_division (FK)' AS "Task";

CREATE TABLE settlements (
    name
        TEXT
        CONSTRAINT "Name must have at least one character." CHECK (LENGTH(name) > 0),
    admin_division
        TEXT
        CONSTRAINT "Name must have at least one character." CHECK (LENGTH(name) > 0),
    type
        TEXT
        CONSTRAINT "Type must be either 'village', 'town', or 'city'" CHECK (type IN ('village', 'town', 'city')),
    mean_temp
        REAL
        CONSTRAINT "Value must be between -50 and +50 degress C" CHECK (mean_temp BETWEEN -50 AND 50),
    PRIMARY KEY(name, admin_division),
    FOREIGN KEY(admin_division) REFERENCES admin_divisions(name)
);          

-- D
SELECT '2 d - Insert 5 rows admin_division, and 5 rows to settlements' AS "Task";

INSERT INTO admin_divisions (name, type)
VALUES
('Ontario', 'province'),
('Quebec', 'province'),
('Yukon', 'territory'),
('Prince Edward Island', 'province'),
('Northwest Territories', 'territory');


INSERT INTO settlements (name, admin_division, type, mean_temp)
VALUES
('Stratford', 'Ontario', 'city', 7.4),
('Stratford', 'Quebec', 'town', 6.5),
('Sherbrooke', 'Quebec', 'city', 10.2),
('Sherbrooke', 'Prince Edward Island', 'village', 4.5),
('Dawson City', 'Yukon', 'town', -3.8);


