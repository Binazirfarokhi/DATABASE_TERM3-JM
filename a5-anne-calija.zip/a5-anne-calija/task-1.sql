-- Task 1: Books, Authors, and Publishers

-- A
SELECT '1 a' AS "Task";

SELECT books.title, books.id as bookID, authored.author_id as "authorID"
FROM books
JOIN authored on books.id = authored.book_id;


-- B
SELECT '1 b' AS "Task";

SELECT 
    books.title,
    books.id as bookID,
    authored.author_id as "authorID",
    authors.name as "author"
FROM books
JOIN authored on books.id = authored.book_id
JOIN authors on authorID = authors.id;


-- C
SELECT '1 c' AS "Task";

SELECT 
    books.title,
    books.id as bookID,
    publishers.publisher,
    authors.name as "author"
FROM books
JOIN authored on books.id = authored.book_id
JOIN authors on authored.author_id = authors.id
JOIN publishers on books.publisher_id = publishers.id;


-- D
SELECT '1 d' AS "Task";

SELECT 
    books.title,
    books.id as bookID,
    publishers.publisher,
    authors.name as "author"
FROM books
JOIN authored on books.id = authored.book_id
JOIN authors on authored.author_id = authors.id
JOIN publishers on books.publisher_id = publishers.id
LIMIT 10 OFFSET 5;
