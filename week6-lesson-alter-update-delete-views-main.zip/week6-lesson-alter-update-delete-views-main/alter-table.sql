-- ALTER TABLE allows you to change the structure of a table afer it has already been created.

-- dropping columns will cause you to lose the data in those columns, so be careful.
-- Dropping a column:
-- ALTER TABLE books
-- DROP COLUMN isbn;

-- there is no IF EXISTS for altering tables; one alteration per query
-- ALTER TABLE books
-- DROP COLUMN format;

-- ALTER TABLE books 
-- DROP COLUMN id;
-- Can't drop primary keys and we can't alter constraints. If you want to do this, you have to create a new table with the desired schema and copy the data from the old table.

-- Add a new column 
-- ALTER TABLE books
-- ADD 
--     description TEXT CHECK(LENGTH(description) > 0)
--     DEFAULT 'Shortlisted for the booker prize';

-- Reame a column
ALTER TABLE books 
RENAME COLUMN description TO summary;
