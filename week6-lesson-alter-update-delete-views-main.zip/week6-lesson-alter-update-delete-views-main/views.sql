-- Views: a stored query with a name that can be queried like a table. 
-- Reasons: avoid duplication of code by writing a query once and then reusing it when needed; we can simplify our code by abstracting some of it in a view; database users with lower levels of access can see an abstracted and curated view of the data in the database with views.
-- they're stored in the db schema 

-- Doing a join query WITHOUT a view to get all books written by Olga Tokarczuk
SELECT books.title, authors.name AS author_name FROM books 
JOIN authored ON books.id = authored.book_id
JOIN authors ON authored.author_id = authors.id 
WHERE authors.name = 'Olga Tokarczuk';

-- use a view to join the books table with the authors table
DROP VIEW IF EXISTS books_with_author;

CREATE VIEW books_with_author AS 
    SELECT books.title, authors.name AS "Author Name" FROM books 
    JOIN authored ON books.id = authored.book_id
    JOIN authors ON authored.author_id = authors.id;

-- query the view like a table 
SELECT * FROM books_with_author WHERE "Author Name" = 'Olga Tokarczuk';