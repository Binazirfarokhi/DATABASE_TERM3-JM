-- enforce foreign key constraints
PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS pets;
DROP TABLE IF EXISTS types;

CREATE TABLE pets (
    id INTEGER,
    name TEXT,
    type INTEGER,
    PRIMARY KEY (id),
    FOREIGN KEY (type) REFERENCES types (id)
        -- ON DELETE SET NULL 
        ON DELETE CASCADE
        -- Cascade will delete rows that refer to the key of the row in the 
        -- other table that was deleted
);

CREATE TABLE types (
    id INTEGER,
    name TEXT,
    class TEXT CHECK(class IN ('mammal', 'fish', 'bird', 'amphibian')),
    PRIMARY KEY (id)
);

INSERT INTO types (name, class) VALUES 
(
    'parakeet',
    'bird'
),
(
    'dog',
    'mammal'
),
(
    'salamander',
    'amphibian'
);

INSERT INTO pets (name, type) VALUES 
(
    'Robert',
    (SELECT id FROM types WHERE name='dog')
),
(
    'Jennifer',
    (SELECT id FROM types WHERE name='salamander')
),
(
    'Beaker',
    (SELECT id FROM types WHERE name='parakeet')
),
(
    'Cornelius',
    (SELECT id FROM types WHERE name='parakeet')
);

-- delete rows from the pets table
-- Must you specify a condition about which data you want to delete, 
-- or else you'll delete all of it
DELETE FROM pets WHERE name = 'Jennifer';

DELETE FROM types WHERE id = 2;

-- Updating rows in tables 
UPDATE pets 
SET name = 'Ms. Beaker'
WHERE name = 'Beaker';