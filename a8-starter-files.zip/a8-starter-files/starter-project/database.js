import { MongoClient, ServerApiVersion } from 'mongodb';

// process.env.CONNECTION is an environment variable with your credentials, pulled from .env 
const client = new MongoClient(process.env.CONNECTION, {
    serverApi: {
    version: ServerApiVersion.v1, strict: true,
    deprecationErrors: true,
    } 
});

// establish the connection
const connection = client.connect();
// Create the database
const database = client.db('our-first-database');

// Close the database connection when the program is terminated
process.on('SIGINT', ()=>{
client.close();
console.log("closed database connection"); process.exit(1);
});

// export the connection and client for use in other scripts
export { connection, database };
 