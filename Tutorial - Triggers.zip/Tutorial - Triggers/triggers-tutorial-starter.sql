DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS registrations;

CREATE TABLE courses (
    id       INTEGER UNIQUE NOT NULL,
    name     TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE students (
    id      INTEGER,
    name    TEXT,
    PRIMARY KEY (id)
);

CREATE TABLE registrations (
    student_id      INTEGER,
    course_id       INTEGER,
    grade           REAL,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students (id),
    FOREIGN KEY (course_id) REFERENCES courses (id)
);

INSERT INTO courses (id, name) VALUES
(4921, 'Intro to Databases'),
(4936, 'Full-Stack Web Development');

INSERT INTO students (name) VALUES 
('Frodo'), ('Aragorn'), ('Eowyn'), ('Elrond'), ('Boromir');

INSERT INTO registrations (student_id, course_id, grade) VALUES
(1, 4921, 68.4),
(2, 4921, 55.3),
(3, 4921, 92.2),
(4, 4921, 88.2),
(1, 4936, 89.1),
(2, 4936, 40.7);

